package com.jan.CS407.exp2;

public class DataKey {
    public static final String LOGIN_REQ = "/login";

    public static final String REGIST_REQ = "/regist";

    public static final String TEST = "/test";
}

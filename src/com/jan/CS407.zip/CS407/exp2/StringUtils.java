package com.jan.CS407.exp2;
/**
* @author jan
* @data 2019年10月20日 上午11:32:23
*/
public class StringUtils {

	public static String[] split(String readLine, String splitStr) {
		String[] s = readLine.split(splitStr);
		return s;
	}

}

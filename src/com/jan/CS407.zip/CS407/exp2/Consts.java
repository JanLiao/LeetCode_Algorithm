package com.jan.CS407.exp2;
/**
* @author Jason.F
* @data 2019.11.11
*/
public class Consts {
	
	public static String url = "jdbc:postgresql://localhost:5432/CS407DB";
	
	public static String driver = "org.postgresql.Driver";

	public static String username = "postgres";
	
	public static String password = "postgre";
	
	//2 hours timeout
	public static int SESSION_TIME = 7200000;
}
